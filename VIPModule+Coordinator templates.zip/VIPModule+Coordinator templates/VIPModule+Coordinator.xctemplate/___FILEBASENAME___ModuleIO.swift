// ___FILEHEADER___

protocol ___VARIABLE_productName:identifier___ModuleInput: AnyObject {}

protocol ___VARIABLE_productName:identifier___ModuleOutput: AnyObject {}
