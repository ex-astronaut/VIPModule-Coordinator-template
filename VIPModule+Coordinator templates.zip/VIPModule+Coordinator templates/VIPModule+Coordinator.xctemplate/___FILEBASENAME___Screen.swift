// ___FILEHEADER___

import UIKit

final class ___VARIABLE_productName:identifier___Screen: BaseScreen {

    // MARK: - Public

    // MARK: External dependencies

    var output: ___VARIABLE_productName:identifier___ScreenOutput!

    // MARK: - Private

    // MARK: Variables

    // MARK: UI

    // MARK: - Override functions

    override func loadView() {
        super.loadView()
    }

}

// MARK: - ___VARIABLE_productName:identifier___ScreenInput

extension ___VARIABLE_productName:identifier___Screen: ___VARIABLE_productName:identifier___ScreenInput {}

// MARK: - Private functions

private extension ___VARIABLE_productName:identifier___Screen {}

// MARK: - Constants

private extension ___VARIABLE_productName:identifier___Screen {

    enum Constants {}

}
