// ___FILEHEADER___

protocol ___VARIABLE_productName:identifier___CoordinatorOutput: AnyObject {}

final class ___VARIABLE_productName:identifier___Coordinator: NavigationCoordinator {

    // MARK: External dependencies

    private weak var output: ___VARIABLE_productName:identifier___CoordinatorOutput?

    // MARK: Variables

    private weak var moduleInput: ___VARIABLE_productName:identifier___ModuleInput?

    // MARK: - Initialization

    init(output: ___VARIABLE_productName:identifier___CoordinatorOutput?) {
        self.output = output
    }

    // MARK: - Override

    // MARK: Functions

    override func makeEntryPoint() -> Coordinatable {
        let module = ___VARIABLE_productName:identifier___ModuleAssembly.buildModule(modulOutput: self)
        moduleInput = module.moduleInput

        return module
    }

}

// MARK: - ___VARIABLE_productName:identifier___ModuleOutput

extension ___VARIABLE_productName:identifier___Coordinator: ___VARIABLE_productName:identifier___ModuleOutput {}
