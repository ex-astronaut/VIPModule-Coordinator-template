// ___FILEHEADER___

protocol ___VARIABLE_productName:identifier___InteractorProtocol {}
