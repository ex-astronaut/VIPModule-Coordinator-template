// ___FILEHEADER___

final class ___VARIABLE_productName:identifier___Presenter {

    // MARK: - Private

    // MARK: External dependencies

    private unowned let view: ___VARIABLE_productName:identifier___ScreenInput
    private let interactor: ___VARIABLE_productName:identifier___InteractorProtocol
    private weak var moduleOutput: ___VARIABLE_productName:identifier___ModuleOutput?

    // MARK: - Variables

    // MARK: - Initialization

    init(view: ___VARIABLE_productName:identifier___ScreenInput,
         interactor: ___VARIABLE_productName:identifier___InteractorProtocol,
         moduleOutput: ___VARIABLE_productName:identifier___ModuleOutput?) {
        self.view = view
        self.interactor = interactor
        self.moduleOutput = moduleOutput
    }

}

// MARK: - LifecycleListener

extension ___VARIABLE_productName:identifier___Presenter: LifecycleListener {}

// MARK: - ___VARIABLE_productName:identifier___ModuleInput

extension ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___ModuleInput {}

// MARK: - ___VARIABLE_productName:identifier___ScreenOutput

extension ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___ScreenOutput {}

// MARK: - Private functions

private extension ___VARIABLE_productName:identifier___Presenter {}

// MARK: - Constants

private extension ___VARIABLE_productName:identifier___Presenter {

    enum Constants {}
    
}
