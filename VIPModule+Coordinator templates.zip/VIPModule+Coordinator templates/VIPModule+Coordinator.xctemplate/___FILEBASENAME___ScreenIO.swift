// ___FILEHEADER___

protocol ___VARIABLE_productName:identifier___ScreenInput: AnyObject {}

protocol ___VARIABLE_productName:identifier___ScreenOutput: AnyObject {}
