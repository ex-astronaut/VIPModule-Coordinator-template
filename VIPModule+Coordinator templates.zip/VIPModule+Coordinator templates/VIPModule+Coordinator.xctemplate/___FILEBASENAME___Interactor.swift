// ___FILEHEADER___

struct ___VARIABLE_productName:identifier___Interactor {}

// MARK: - ___VARIABLE_productName:identifier___InteractorProtocol

extension ___VARIABLE_productName:identifier___Interactor: ___VARIABLE_productName:identifier___InteractorProtocol {}
