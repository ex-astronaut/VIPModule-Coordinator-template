// ___FILEHEADER___

final class ___VARIABLE_productName:identifier___ModuleAssembly {

    // MARK: - Public functions

    static func buildModule(modulOutput: ___VARIABLE_productName:identifier___ModuleOutput) -> VIPModule<___VARIABLE_productName:identifier___ModuleInput> {
        let view = ___VARIABLE_productName:identifier___Screen()
        let interactor = ___VARIABLE_productName:identifier___Interactor()
        let presenter = ___VARIABLE_productName:identifier___Presenter(
            view: view,
            interactor: interactor,
            moduleOutput: modulOutput
        )

        view.output = presenter
        view.addLifecycleListener(presenter)

        return VIPModule(view, presenter)
    }

}
